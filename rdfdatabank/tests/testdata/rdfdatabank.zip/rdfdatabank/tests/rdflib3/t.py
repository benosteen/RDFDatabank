

class Foo(object):
    """
    """

